create
    definer = root@localhost procedure find_customer(IN id int)
BEGIN
SELECT * FROM customers WHERE customerNumber = id;
END;

